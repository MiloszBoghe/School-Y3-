﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RefVsValue
{
    public class Balloon
    {
        public double Size { get; set; }
        public string ColorHex { get; set; }
    }
}
